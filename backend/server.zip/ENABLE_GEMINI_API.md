# 🔧 Enable Gemini API - Fix 404 Errors

## ⚠️ Problem
All Gemini models return **404 Not Found** errors, which means the API is not enabled for your project.

## ✅ Solution: Enable the Gemini API

### Step 1: Go to Google Cloud Console

Visit: https://console.cloud.google.com/apis/library/generativelanguage.googleapis.com

OR

1. Go to https://console.cloud.google.com/
2. Click on "APIs & Services" in the left menu
3. Click "Library"
4. Search for "Generative Language API"

### Step 2: Enable the API

1. Click on "**Generative Language API**"
2. Click the "**ENABLE**" button
3. Wait a few seconds for it to activate

### Step 3: Verify API is Enabled

After enabling, check:
1. Go to https://console.cloud.google.com/apis/dashboard
2. You should see "Generative Language API" in the list

### Step 4: Create New API Keys

**IMPORTANT**: After enabling the API, create NEW API keys:

1. Visit https://aistudio.google.com/app/apikey
2. Click "Create API Key"
3. **Select the project where you just enabled the API**
4. Copy the new key
5. Repeat 4 more times for 5 keys total

### Step 5: Update .env with New Keys

Replace the keys in `backend/.env`:

```env
GEMINI_API_KEY_1=AIzaSy_YOUR_NEW_KEY_1
GEMINI_API_KEY_2=AIzaSy_YOUR_NEW_KEY_2
GEMINI_API_KEY_3=AIzaSy_YOUR_NEW_KEY_3
GEMINI_API_KEY_4=AIzaSy_YOUR_NEW_KEY_5
GEMINI_API_KEY_5=AIzaSy_YOUR_NEW_KEY_5
```

### Step 6: Test Again

```powershell
node testModels.js
```

You should now see ✅ SUCCESS!

---

## 🔍 Alternative: Check Which Project Your Keys Are Using

Your current API keys might be from a project that doesn't have the Gemini API enabled:

1. Go to https://console.cloud.google.com/apis/credentials
2. Look for your API keys
3. Check which project they belong to
4. Make sure that project has "Generative Language API" enabled

---

## 📋 Quick Checklist

- [ ] Enabled "Generative Language API" in Google Cloud Console
- [ ] Created new API keys AFTER enabling the API
- [ ] Selected the correct project when creating keys
- [ ] Updated all 5 keys in .env file
- [ ] Ran `node testModels.js` successfully

---

## 💡 Still Not Working?

If you're still getting 404 errors after following all steps:

### Option A: Try a Different Google Account
Some accounts may have restrictions. Try creating API keys with a different Google account.

### Option B: Wait 5-10 Minutes
Sometimes it takes a few minutes for API enablement to propagate.

### Option C: Use Groq Instead (FREE Alternative)
Groq offers free API access to Llama models with generous limits:

1. Visit: https://console.groq.com/
2. Get a free API key
3. I can help you switch to Groq if Gemini continues to fail

---

## 🎯 Expected Result

After fixing, `node testModels.js` should show:

```
✅ SUCCESS
1. 🟢 gemini-1.5-flash
   Response: "OK"

🎯 RECOMMENDATION:
Use this model in gemini.service.js:
   model: 'gemini-1.5-flash'
```

Good luck! 🚀
