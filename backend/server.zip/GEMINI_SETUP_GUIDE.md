# 🚀 Gemini API Setup Guide

## Current Status: ⚠️ API Keys Invalid

Your current Gemini API keys are returning 404 errors, which means they're either:
- Invalid or expired
- Don't have access to Gemini models
- From an old API version

## 📋 Gemini 2.0 Flash - What You're Using

**Model**: `gemini-2.0-flash-exp`
- ⚡ Fastest Gemini model available
- 🆓 Free tier available
- 🌍 Multilingual support
- 🧠 Advanced reasoning capabilities
- 📝 Long context window (up to 1M tokens)

**Why Gemini 2.0 Flash?**
- Latest generation (2.0) with improved performance
- 2x faster than Gemini 1.5
- Better at understanding context and complex queries
- Perfect for RAG (Retrieval-Augmented Generation)
- Excellent for faculty recommendations and scheduling

## 📋 Step-by-Step Setup

### Step 1: Generate New API Keys

1. **Visit Google AI Studio**
   - URL: https://aistudio.google.com/app/apikey
   - Sign in with your Google account

2. **Create 5 New API Keys**
   - Click the "**Create API Key**" button
   - Choose "**Create API key in new project**" or select existing project
   - **IMPORTANT**: Copy the key immediately (you can only see it once!)
   - Repeat this process 5 times to get 5 different keys

   Example key format: `AIzaSyBxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

3. **Why 5 Keys?**
   - Automatic failover if one key hits rate limits
   - Better reliability with key rotation
   - Prevents service interruption

### Step 2: Update Your .env File

Open `backend/.env` and replace the old keys:

```env
# OLD KEYS (INVALID) ❌
GEMINI_API_KEY_1=AQ.Ab8RN6LzxyiukVbiIMb4hlwrf2ZisMULlBbX9tQZjTtXsEz_vw
GEMINI_API_KEY_2=AQ.Ab8RN6JHacTzdvXF1ekNb1DiaDQjEFIJ7Hih0gGAvSBsvv3q4g
GEMINI_API_KEY_3=AQ.Ab8RN6IlalukAf_AQmYbHSEOYEme_830qrWzm8SHosCTuG-JDQ
GEMINI_API_KEY_4=AQ.Ab8RN6JEHQ74HspQNMlq-hDoa2bBszCr-ICSUqgu4jmBgcOl5g
GEMINI_API_KEY_5=AQ.Ab8RN6KzZSllTeBghMowzl5b1sOT9gNvTIEW_VrGdaMx_-9zvw

# NEW VALID KEYS ✅
GEMINI_API_KEY_1=AIzaSyYOUR_FIRST_KEY_HERE
GEMINI_API_KEY_2=AIzaSyYOUR_SECOND_KEY_HERE
GEMINI_API_KEY_3=AIzaSyYOUR_THIRD_KEY_HERE
GEMINI_API_KEY_4=AIzaSyYOUR_FOURTH_KEY_HERE
GEMINI_API_KEY_5=AIzaSyYOUR_FIFTH_KEY_HERE
```

### Step 3: Test Your Keys

Run the test script to verify everything works:

```powershell
# Navigate to backend directory
cd "c:\Programming\new timetable\backend"

# Run the test script
node testModels.js
```

**Expected Output (Success):**
```
════════════════════════════════════════════════════════════════════════════════
🧪 TESTING GEMINI MODELS
════════════════════════════════════════════════════════════════════════════════

🔄 Testing: gemini-2.0-flash-exp...
   ✅ SUCCESS - Response: "OK"

📊 RESULTS:
✅ 1 WORKING MODEL(S):
1. 🟢 gemini-2.0-flash-exp
   Response: "OK"

🎯 RECOMMENDATION:
Use this model in gemini.service.js:
   model: 'gemini-2.0-flash-exp'
════════════════════════════════════════════════════════════════════════════════
```

### Step 4: Restart Your Server

If your backend server is running, restart it to load the new keys:

```powershell
# Press Ctrl+C to stop the server
# Then start it again
npm start
```

### Step 5: Test the AI Chat

1. Open your application frontend
2. Navigate to the Schedule page
3. Click on a schedule to open the Edit Modal
4. Click the **AI Assistant** button (Bot icon with sparkles)
5. Try sending a message like "Hello" or "Who should teach CS101?"

## 🎯 Features You'll Get

Once your API keys are working:

✅ **RAG-Powered AI Chat**
- Multilingual support (English, Filipino, Spanish, etc.)
- Context-aware responses about your schedules, faculty, rooms
- Smart recommendations based on teaching history

✅ **Faculty Recommendations**
- Prioritizes faculty with experience teaching specific subjects
- Shows years of experience: "Prof. Smith taught this subject for 5 semesters"
- Considers current workload and availability

✅ **5-Key Fallback System**
- Automatic rotation when one key hits rate limits
- 1-minute cooldown for failed keys
- Continues working even if some keys fail

✅ **Scheduling Assistant**
- Helps resolve time conflicts
- Suggests alternative time slots
- Explains scheduling constraints

## 🔍 Troubleshooting

### Issue: "All API keys exhausted"
**Solution**: 
- Check if all 5 keys are valid
- Verify you're not hitting rate limits
- Wait 1 minute for cooldown to reset

### Issue: "404 Not Found"
**Solution**:
- Keys are invalid - generate new ones
- Make sure you're copying the full API key
- Check that keys start with `AIzaSy`

### Issue: "PERMISSION_DENIED"
**Solution**:
- Enable the Generative Language API in Google Cloud Console
- Go to: https://console.cloud.google.com/apis/library
- Search for "Generative Language API"
- Click "Enable"

### Issue: "quota exceeded"
**Solution**:
- You've hit the free tier limit
- Wait for quota reset (usually daily)
- Consider upgrading to paid tier for higher limits

## 📊 Free Tier Limits

**Gemini 2.0 Flash (Free)**:
- 10 requests per minute (RPM)
- 1,500 requests per day (RPD)
- 1 million tokens per day

**Gemini 1.5 Flash (Free - Fallback)**:
- 15 requests per minute
- 1,500 requests per day
- 1 million tokens per day

**Why 5 Keys Help**:
With 5 keys, you effectively get:
- 50 requests per minute (5 × 10)
- 7,500 requests per day (5 × 1,500)

**Note**: Gemini 2.0 is newer and faster but has slightly lower RPM. The code will automatically fall back to other models if rate limited.

## 📚 Additional Resources

- **API Documentation**: https://ai.google.dev/docs
- **Get API Keys**: https://aistudio.google.com/app/apikey
- **Pricing**: https://ai.google.dev/pricing
- **Community**: https://developers.google.com/community

## ✅ Checklist

- [ ] Generated 5 new Gemini API keys
- [ ] Updated all 5 keys in `.env` file
- [ ] Ran `node testModels.js` successfully
- [ ] Restarted backend server
- [ ] Tested AI chat in the application
- [ ] Verified faculty recommendations work

---

**Need Help?**
If you're still having issues after following this guide, check:
1. Console logs for specific error messages
2. Verify keys are correctly formatted (no extra spaces)
3. Ensure MongoDB connection is working
4. Check that frontend is connecting to backend

**Success Indicator**: When you see "✓ Success with API key X" in your console logs! 🎉
