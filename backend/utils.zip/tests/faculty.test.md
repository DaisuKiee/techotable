# Faculty CRUD Testing Guide

## Prerequisites
- Backend server running on port 5000
- Database seeded with test data
- Valid JWT token (login first)

---

## Test Sequence

### 1. Login as Admin
```bash
curl -X POST http://localhost:5000/api/auth/login ^
  -H "Content-Type: application/json" ^
  -d "{\"email\":\"admin@ctu.edu.ph\",\"password\":\"admin123\"}"
```

**Save the token from response!**

---

### 2. Get All Faculty
```bash
curl http://localhost:5000/api/faculty ^
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected:** List of 3 faculty members (from seed data)

---

### 3. Get Faculty by ID
```bash
# Replace FACULTY_ID with actual ID from previous response
curl http://localhost:5000/api/faculty/FACULTY_ID ^
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected:** Detailed faculty information including qualifications and teaching history

---

### 4. Create New Faculty Member
```bash
curl -X POST http://localhost:5000/api/faculty ^
  -H "Authorization: Bearer YOUR_TOKEN_HERE" ^
  -H "Content-Type: application/json" ^
  -d "{\"email\":\"testfaculty@ctu.edu.ph\",\"password\":\"test123\",\"firstName\":\"Test\",\"lastName\":\"Faculty\",\"employeeId\":\"FAC-2024-999\",\"position\":\"Instructor\",\"specializations\":[\"Testing\",\"QA\"],\"maxTeachingLoad\":18}"
```

**Expected:** 201 status with new faculty data

---

### 5. Update Faculty Member
```bash
curl -X PUT http://localhost:5000/api/faculty/FACULTY_ID ^
  -H "Authorization: Bearer YOUR_TOKEN_HERE" ^
  -H "Content-Type: application/json" ^
  -d "{\"position\":\"Senior Instructor\",\"specializations\":[\"Testing\",\"QA\",\"Automation\"]}"
```

**Expected:** 200 status with updated data

---

### 6. Add Qualification
```bash
curl -X POST http://localhost:5000/api/faculty/FACULTY_ID/qualifications ^
  -H "Authorization: Bearer YOUR_TOKEN_HERE" ^
  -H "Content-Type: application/json" ^
  -d "{\"degree\":\"MS\",\"field\":\"Software Engineering\",\"institution\":\"CTU\",\"yearObtained\":2020}"
```

**Expected:** Qualification added to faculty profile

---

### 7. Add Teaching History
```bash
curl -X POST http://localhost:5000/api/faculty/FACULTY_ID/teaching-history ^
  -H "Authorization: Bearer YOUR_TOKEN_HERE" ^
  -H "Content-Type: application/json" ^
  -d "{\"subjectCode\":\"IT101\",\"subjectName\":\"Programming Fundamentals\",\"semester\":\"1\",\"academicYear\":\"2025-2026\",\"program\":\"BSIT\",\"rating\":4.5}"
```

**Expected:** Teaching history entry added

---

### 8. Check Faculty Workload
```bash
curl http://localhost:5000/api/faculty/FACULTY_ID/workload ^
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected:** Workload statistics showing current/max load and percentage

---

### 9. Update Faculty Load
```bash
# Increase load by 6 units
curl -X PUT http://localhost:5000/api/faculty/FACULTY_ID/load ^
  -H "Authorization: Bearer YOUR_TOKEN_HERE" ^
  -H "Content-Type: application/json" ^
  -d "{\"loadChange\":6}"
```

**Expected:** Current load increased

---

### 10. Get Available Faculty
```bash
curl http://localhost:5000/api/faculty/available ^
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected:** List of faculty with available capacity

---

### 11. Get Faculty by Specialization
```bash
curl http://localhost:5000/api/faculty/specialization/Programming ^
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected:** Faculty members with "Programming" specialization

---

### 12. Filter Faculty
```bash
# Get active faculty in CoTE department
curl "http://localhost:5000/api/faculty?department=CoTE&isActive=true" ^
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected:** Filtered list

---

### 13. Search Faculty
```bash
# Search by name
curl "http://localhost:5000/api/faculty?search=john" ^
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected:** Faculty members matching "john"

---

### 14. Delete Faculty (Soft Delete)
```bash
curl -X DELETE http://localhost:5000/api/faculty/FACULTY_ID ^
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected:** Faculty deactivated (isActive = false)

---

## Test Checklist

- [ ] Can login as admin
- [ ] Can get all faculty
- [ ] Can get faculty by ID
- [ ] Can create new faculty with user account
- [ ] Employee ID uniqueness enforced
- [ ] Can update faculty information
- [ ] Can add qualifications
- [ ] Can add teaching history
- [ ] Can view workload statistics
- [ ] Can update current load
- [ ] Can filter by department
- [ ] Can filter by specialization
- [ ] Can search by name/employee ID
- [ ] Can get available faculty
- [ ] Can soft delete faculty
- [ ] Authorization works (admin/scheduling officer only for writes)
- [ ] Non-admin users blocked from create/update/delete

---

## Error Cases to Test

### Duplicate Employee ID
```bash
# Try creating faculty with existing employee ID
curl -X POST http://localhost:5000/api/faculty ^
  -H "Authorization: Bearer YOUR_TOKEN_HERE" ^
  -H "Content-Type: application/json" ^
  -d "{\"email\":\"another@ctu.edu.ph\",\"password\":\"test123\",\"firstName\":\"Test\",\"lastName\":\"Duplicate\",\"employeeId\":\"FAC-2024-001\",\"position\":\"Instructor\"}"
```

**Expected:** 400 error - "Employee ID already exists"

---

### Missing Required Fields
```bash
curl -X POST http://localhost:5000/api/faculty ^
  -H "Authorization: Bearer YOUR_TOKEN_HERE" ^
  -H "Content-Type: application/json" ^
  -d "{\"email\":\"incomplete@ctu.edu.ph\"}"
```

**Expected:** 400 error with validation messages

---

### Unauthorized Access
```bash
# Login as student first
curl -X POST http://localhost:5000/api/auth/login ^
  -H "Content-Type: application/json" ^
  -d "{\"email\":\"student@ctu.edu.ph\",\"password\":\"student123\"}"

# Try to create faculty with student token
curl -X POST http://localhost:5000/api/faculty ^
  -H "Authorization: Bearer STUDENT_TOKEN" ^
  -H "Content-Type: application/json" ^
  -d "{...}"
```

**Expected:** 403 error - "Not authorized"

---

### Invalid Faculty ID
```bash
curl http://localhost:5000/api/faculty/invalid-id-12345 ^
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected:** 404 error - "Faculty member not found"

---

## Success Criteria

✅ All CRUD operations work correctly  
✅ Authorization enforced properly  
✅ Validation prevents bad data  
✅ Workload tracking accurate  
✅ Filtering and search functional  
✅ Relationships preserved (User ↔ Faculty)  
✅ Soft delete works  
✅ Error messages clear and helpful  

---

## Postman Collection

Import this into Postman for easier testing:

1. Create collection: "CoTE Faculty API"
2. Add environment variable: `baseUrl` = `http://localhost:5000/api`
3. Add environment variable: `token` = (set after login)
4. Import requests from FACULTY_API.md

---

## Next Steps After Testing

1. ✅ Verify all endpoints work
2. Test with frontend integration
3. Performance test with large datasets
4. Security audit
5. Write unit tests (Jest)
