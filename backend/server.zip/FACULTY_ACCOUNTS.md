# Faculty Accounts - CoTE Timetabling System

This document lists all faculty accounts created for the CTU Daanbantayan timetabling system.

## System Overview

### Programs (7 Total)
The system manages faculty across **7 academic programs**:
1. **BSIT** - Bachelor of Science in Information Technology
2. **BSHM** - Bachelor of Science in Hospitality Management
3. **BIT-ET** - Bachelor of Industrial Technology - Electronics Technology
4. **BIT-CT** - Bachelor of Industrial Technology - Computer Technology
5. **BIT-AT** - Bachelor of Industrial Technology - Automotive Technology
6. **BSFI** - Bachelor of Science in Fisheries
7. **BSIE** - Bachelor of Science in Industrial Engineering

### Faculty Distribution
- **Total Faculty**: 70 members
- **Faculty per Program**: 10
- **Default Password**: `faculty123`
- **Department**: All belong to CoTE (College of Technology)

### Program Managers
Each program has a dedicated program manager who can only access their program's data:
- **BSIT Manager**: bsit.manager@ctu.edu.ph / manager123
- **BSHM Manager**: bshm.manager@ctu.edu.ph / manager123
- **BIT-ET Manager**: bitet.manager@ctu.edu.ph / manager123
- **BIT-CT Manager**: bitct.manager@ctu.edu.ph / manager123
- **BIT-AT Manager**: bitat.manager@ctu.edu.ph / manager123
- **BSFI Manager**: bsfi.manager@ctu.edu.ph / manager123
- **BSIE Manager**: bsie.manager@ctu.edu.ph / manager123

---

## Faculty Accounts by Program

### BSIT Faculty (10 members)
**Specializations**: Programming, Web Development, Database Management, Systems Analysis, Networking, Mobile Development, Software Engineering, IT Project Management

| Employee ID | Email | Name |
|-------------|-------|------|
| FAC-BSIT-001 | teach-bsit-1@ctu.edu.ph | Teach-BSIT 1 |
| FAC-BSIT-002 | teach-bsit-2@ctu.edu.ph | Teach-BSIT 2 |
| FAC-BSIT-003 | teach-bsit-3@ctu.edu.ph | Teach-BSIT 3 |
| FAC-BSIT-004 | teach-bsit-4@ctu.edu.ph | Teach-BSIT 4 |
| FAC-BSIT-005 | teach-bsit-5@ctu.edu.ph | Teach-BSIT 5 |
| FAC-BSIT-006 | teach-bsit-6@ctu.edu.ph | Teach-BSIT 6 |
| FAC-BSIT-007 | teach-bsit-7@ctu.edu.ph | Teach-BSIT 7 |
| FAC-BSIT-008 | teach-bsit-8@ctu.edu.ph | Teach-BSIT 8 |
| FAC-BSIT-009 | teach-bsit-9@ctu.edu.ph | Teach-BSIT 9 |
| FAC-BSIT-010 | teach-bsit-10@ctu.edu.ph | Teach-BSIT 10 |

---

### BSHM Faculty (10 members)
**Specializations**: Hotel Management, Food and Beverage Service, Culinary Arts, Tourism Management, Restaurant Management, Event Management, Hospitality Operations, Customer Service

| Employee ID | Email | Name |
|-------------|-------|------|
| FAC-BSHM-001 | teach-bshm-1@ctu.edu.ph | Teach-BSHM 1 |
| FAC-BSHM-002 | teach-bshm-2@ctu.edu.ph | Teach-BSHM 2 |
| FAC-BSHM-003 | teach-bshm-3@ctu.edu.ph | Teach-BSHM 3 |
| FAC-BSHM-004 | teach-bshm-4@ctu.edu.ph | Teach-BSHM 4 |
| FAC-BSHM-005 | teach-bshm-5@ctu.edu.ph | Teach-BSHM 5 |
| FAC-BSHM-006 | teach-bshm-6@ctu.edu.ph | Teach-BSHM 6 |
| FAC-BSHM-007 | teach-bshm-7@ctu.edu.ph | Teach-BSHM 7 |
| FAC-BSHM-008 | teach-bshm-8@ctu.edu.ph | Teach-BSHM 8 |
| FAC-BSHM-009 | teach-bshm-9@ctu.edu.ph | Teach-BSHM 9 |
| FAC-BSHM-010 | teach-bshm-10@ctu.edu.ph | Teach-BSHM 10 |

---

### BIT-ET Faculty (10 members)
**Specializations**: Electronics Technology, Circuit Design, Microcontrollers, Digital Electronics, Industrial Electronics, Instrumentation, Electronic Maintenance, PCB Design

| Employee ID | Email | Name |
|-------------|-------|------|
| FAC-BIT-ET-001 | teach-bit-et-1@ctu.edu.ph | Teach-BITET 1 |
| FAC-BIT-ET-002 | teach-bit-et-2@ctu.edu.ph | Teach-BITET 2 |
| FAC-BIT-ET-003 | teach-bit-et-3@ctu.edu.ph | Teach-BITET 3 |
| FAC-BIT-ET-004 | teach-bit-et-4@ctu.edu.ph | Teach-BITET 4 |
| FAC-BIT-ET-005 | teach-bit-et-5@ctu.edu.ph | Teach-BITET 5 |
| FAC-BIT-ET-006 | teach-bit-et-6@ctu.edu.ph | Teach-BITET 6 |
| FAC-BIT-ET-007 | teach-bit-et-7@ctu.edu.ph | Teach-BITET 7 |
| FAC-BIT-ET-008 | teach-bit-et-8@ctu.edu.ph | Teach-BITET 8 |
| FAC-BIT-ET-009 | teach-bit-et-9@ctu.edu.ph | Teach-BITET 9 |
| FAC-BIT-ET-010 | teach-bit-et-10@ctu.edu.ph | Teach-BITET 10 |

---

### BIT-CT Faculty (10 members)
**Specializations**: Computer Hardware, System Administration, Technical Support, Computer Maintenance, Network Configuration, PC Assembly, Hardware Troubleshooting, System Integration

| Employee ID | Email | Name |
|-------------|-------|------|
| FAC-BIT-CT-001 | teach-bit-ct-1@ctu.edu.ph | Teach-BITCT 1 |
| FAC-BIT-CT-002 | teach-bit-ct-2@ctu.edu.ph | Teach-BITCT 2 |
| FAC-BIT-CT-003 | teach-bit-ct-3@ctu.edu.ph | Teach-BITCT 3 |
| FAC-BIT-CT-004 | teach-bit-ct-4@ctu.edu.ph | Teach-BITCT 4 |
| FAC-BIT-CT-005 | teach-bit-ct-5@ctu.edu.ph | Teach-BITCT 5 |
| FAC-BIT-CT-006 | teach-bit-ct-6@ctu.edu.ph | Teach-BITCT 6 |
| FAC-BIT-CT-007 | teach-bit-ct-7@ctu.edu.ph | Teach-BITCT 7 |
| FAC-BIT-CT-008 | teach-bit-ct-8@ctu.edu.ph | Teach-BITCT 8 |
| FAC-BIT-CT-009 | teach-bit-ct-9@ctu.edu.ph | Teach-BITCT 9 |
| FAC-BIT-CT-010 | teach-bit-ct-10@ctu.edu.ph | Teach-BITCT 10 |

---

### BIT-AT Faculty (10 members)
**Specializations**: Automotive Technology, Engine Repair, Vehicle Diagnostics, Automotive Electronics, Transmission Systems, Brake Systems, Vehicle Maintenance, Auto Body Repair

| Employee ID | Email | Name |
|-------------|-------|------|
| FAC-BIT-AT-001 | teach-bit-at-1@ctu.edu.ph | Teach-BITAT 1 |
| FAC-BIT-AT-002 | teach-bit-at-2@ctu.edu.ph | Teach-BITAT 2 |
| FAC-BIT-AT-003 | teach-bit-at-3@ctu.edu.ph | Teach-BITAT 3 |
| FAC-BIT-AT-004 | teach-bit-at-4@ctu.edu.ph | Teach-BITAT 4 |
| FAC-BIT-AT-005 | teach-bit-at-5@ctu.edu.ph | Teach-BITAT 5 |
| FAC-BIT-AT-006 | teach-bit-at-6@ctu.edu.ph | Teach-BITAT 6 |
| FAC-BIT-AT-007 | teach-bit-at-7@ctu.edu.ph | Teach-BITAT 7 |
| FAC-BIT-AT-008 | teach-bit-at-8@ctu.edu.ph | Teach-BITAT 8 |
| FAC-BIT-AT-009 | teach-bit-at-9@ctu.edu.ph | Teach-BITAT 9 |
| FAC-BIT-AT-010 | teach-bit-at-10@ctu.edu.ph | Teach-BITAT 10 |

---

### BSFI Faculty (10 members)
**Specializations**: Aquaculture, Fish Processing, Marine Biology, Fisheries Management, Aquatic Ecosystems, Fish Breeding, Coastal Resource Management, Fisheries Economics

| Employee ID | Email | Name |
|-------------|-------|------|
| FAC-BSFI-001 | teach-bsfi-1@ctu.edu.ph | Teach-BSFI 1 |
| FAC-BSFI-002 | teach-bsfi-2@ctu.edu.ph | Teach-BSFI 2 |
| FAC-BSFI-003 | teach-bsfi-3@ctu.edu.ph | Teach-BSFI 3 |
| FAC-BSFI-004 | teach-bsfi-4@ctu.edu.ph | Teach-BSFI 4 |
| FAC-BSFI-005 | teach-bsfi-5@ctu.edu.ph | Teach-BSFI 5 |
| FAC-BSFI-006 | teach-bsfi-6@ctu.edu.ph | Teach-BSFI 6 |
| FAC-BSFI-007 | teach-bsfi-7@ctu.edu.ph | Teach-BSFI 7 |
| FAC-BSFI-008 | teach-bsfi-8@ctu.edu.ph | Teach-BSFI 8 |
| FAC-BSFI-009 | teach-bsfi-9@ctu.edu.ph | Teach-BSFI 9 |
| FAC-BSFI-010 | teach-bsfi-10@ctu.edu.ph | Teach-BSFI 10 |

---

### BSIE Faculty (10 members)
**Specializations**: Industrial Engineering, Production Planning, Quality Control, Operations Management, Manufacturing Systems, Ergonomics, Supply Chain Management, Process Improvement

| Employee ID | Email | Name |
|-------------|-------|------|
| FAC-BSIE-001 | teach-bsie-1@ctu.edu.ph | Teach-BSIE 1 |
| FAC-BSIE-002 | teach-bsie-2@ctu.edu.ph | Teach-BSIE 2 |
| FAC-BSIE-003 | teach-bsie-3@ctu.edu.ph | Teach-BSIE 3 |
| FAC-BSIE-004 | teach-bsie-4@ctu.edu.ph | Teach-BSIE 4 |
| FAC-BSIE-005 | teach-bsie-5@ctu.edu.ph | Teach-BSIE 5 |
| FAC-BSIE-006 | teach-bsie-6@ctu.edu.ph | Teach-BSIE 6 |
| FAC-BSIE-007 | teach-bsie-7@ctu.edu.ph | Teach-BSIE 7 |
| FAC-BSIE-008 | teach-bsie-8@ctu.edu.ph | Teach-BSIE 8 |
| FAC-BSIE-009 | teach-bsie-9@ctu.edu.ph | Teach-BSIE 9 |
| FAC-BSIE-010 | teach-bsie-10@ctu.edu.ph | Teach-BSIE 10 |

---

## Additional Details

### Faculty Profile Features
- **Positions**: Professor, Associate Professor, Assistant Professor, Instructor
- **Qualifications**: BS/MS/PhD in their respective fields
- **Max Teaching Load**: 18-40 hours per week (varies by faculty)
- **Current Load**: 0 hours (no assignments yet)
- **Status**: All faculty are active
- **Specializations**: Each faculty has 2-4 relevant specializations

### Field of Study by Program
- **BSIT**: Computer Science
- **BSHM**: Hospitality Management
- **BIT-ET**: Electronics Technology
- **BIT-CT**: Computer Technology
- **BIT-AT**: Automotive Technology
- **BSFI**: Fisheries
- **BSIE**: Industrial Engineering

---

## How to Run the Script

To regenerate or reset the faculty data:

```bash
cd backend
node createFacultyData.js
```

**⚠️ Warning**: This will delete ALL existing faculty members and their user accounts, then create new ones.

---

## Login Credentials

All faculty accounts use the same password: **faculty123**

### Examples:
- Email: `teach-bsit-1@ctu.edu.ph` / Password: `faculty123`
- Email: `teach-bshm-5@ctu.edu.ph` / Password: `faculty123`
- Email: `teach-bit-et-10@ctu.edu.ph` / Password: `faculty123`

---

## System Architecture Notes

### Access Control
- **Faculty Role**: Can teach across multiple programs based on their specializations
- **Program Managers**: Restricted to managing ONLY their assigned program
- **Admin**: Full access to all programs and faculty

### Faculty-Program Relationship
- Faculty members are NOT restricted to specific programs
- Assignment to subjects is based on specializations, not program
- This allows flexibility (e.g., a programming faculty can teach BSIT, BIT-CT subjects)

### Database Schema
- **User Model**: Contains basic account info and role
- **Faculty Model**: Contains teaching profile, linked to User via `facultyProfile` reference
- Each faculty profile includes specializations, qualifications, and workload data
