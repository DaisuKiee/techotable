# AI RAG Faculty Recommendation System

## Overview
The AI RAG (Retrieval-Augmented Generation) system now includes intelligent faculty recommendations based on teaching experience and background.

## Key Features

### 1. **Experience-Based Faculty Recommendations**
The system prioritizes faculty members based on:
- **Years teaching the specific subject** (highest priority)
- Total teaching experience (semesters taught)
- Teaching quality ratings
- Current workload availability
- Specializations matching the subject area

### 2. **Priority Scoring Algorithm**
```javascript
priorityScore = (subjectExperience × 10) + (totalExperience × 2) + (avgRating × 5) + (availableLoadBonus)
```

**Weight Distribution:**
- Subject-specific experience: **10 points per semester**
- General teaching experience: **2 points per semester**
- Average rating: **5 points per star**
- Available workload: **5 bonus points if > 6 hours**

### 3. **Teaching History Tracking**
Faculty model includes:
```javascript
teachingHistory: [{
  subjectCode: String,      // e.g., "CS101"
  subjectName: String,      // e.g., "Data Structures"
  semester: String,         // e.g., "1st Semester"
  academicYear: String,     // e.g., "2024-2025"
  program: String,          // e.g., "BSCS"
  rating: Number           // 0-5 stars
}]
```

## API Endpoints

### POST `/api/ai/recommend-faculty`
Recommends faculty for a specific subject based on experience.

**Request Body:**
```json
{
  "subjectCode": "CS101",
  "subjectName": "Data Structures"
}
```

**Response:**
```json
{
  "success": true,
  "subject": {
    "code": "CS101",
    "name": "Data Structures"
  },
  "recommendations": [
    {
      "rank": 1,
      "facultyId": "507f1f77bcf86cd799439011",
      "name": "Dr. John Smith",
      "employeeId": "FAC-2020-001",
      "specializations": ["Algorithms", "Data Structures"],
      "subjectExperience": 5,
      "totalExperience": 15,
      "avgRating": "4.8",
      "currentLoad": 18,
      "maxLoad": 24,
      "availableLoad": 6,
      "priorityScore": "89.00",
      "recommendation": "⭐ Highly Recommended - 5 semesters teaching this subject"
    }
  ],
  "totalFaculty": 45
}
```

### POST `/api/ai/chat`
Enhanced with faculty experience context. Now automatically includes:
- Top 10 most experienced faculty with their teaching history
- Subject-specific experience summaries
- Experience-based recommendations in responses

## RAG System Enhancements

### System Prompt Features
1. **Faculty Experience Summary**
   - Lists top 10 experienced faculty
   - Shows their subject expertise with years
   - Example: "Prof. Smith: CS101 (5y), CS102 (3y), CS201 (2y) | Total: 10 semesters"

2. **Recommendation Rules**
   ```
   Priority Order:
   1. Experience First - Most years teaching the specific subject
   2. Specialization Match - Field expertise alignment
   3. Current Workload - Not overloaded
   4. Teaching Quality - Higher ratings preferred
   5. Availability - Time slot compatibility
   ```

3. **Response Formatting**
   ```
   👨‍🏫 **[Faculty Name]**
   ⭐ [X years experience teaching this subject]
   📚 Specialization: [field]
   📊 Current load: [X/Y hours]
   ```

## Usage Examples

### Ask AI for Faculty Recommendations
**User:** "Who should teach Data Structures?"

**AI Response:**
```
Based on teaching experience, here are my top recommendations for Data Structures:

👨‍🏫 **Dr. John Smith**
⭐ 5 semesters teaching this subject
📚 Specialization: Algorithms, Data Structures
📊 Current load: 18/24 hours
✅ Highly recommended - Most experienced with this subject

👨‍🏫 **Prof. Maria Garcia**
⭐ 3 semesters teaching this subject
📚 Specialization: Computer Science, Programming
📊 Current load: 15/24 hours
✅ Very experienced - Good availability

👨‍🏫 **Dr. Robert Chen**
⭐ 2 semesters teaching this subject
📚 Specialization: Software Engineering
📊 Current load: 12/24 hours
✅ Experienced - Excellent availability
```

### Multilingual Support
**User (Filipino):** "Sino ang best teacher para sa Data Structures?"

**AI Response (Filipino):**
```
Base sa teaching experience, narito ang mga recommended faculty para sa Data Structures:

👨‍🏫 **Dr. John Smith**
⭐ 5 semester na nagturo ng subject na ito
📚 Specialization: Algorithms, Data Structures
✅ Highly recommended - Pinaka-experienced sa subject na ito
```

## Integration with Schedule Builder

### Automatic Context Loading
When users open the AI chat from the schedule assignment modal:
1. Current schedule data is passed as context
2. AI automatically loads faculty with teaching history
3. Recommendations consider:
   - Subject being scheduled
   - Faculty availability
   - Experience with that specific subject

### Quick Suggestions
Pre-configured prompts include:
- "Who is the best faculty to teach this subject?"
- "Show me experienced faculty for [subject]"
- "Recommend faculty with highest ratings"

## Data Requirements

### For Optimal Recommendations
Faculty records should include:
1. **Complete teaching history** with subject codes
2. **Ratings** from previous semesters
3. **Specializations** that match curriculum areas
4. **Current workload** kept up-to-date

### Sample Teaching History Entry
```javascript
{
  subjectCode: "CS101",
  subjectName: "Data Structures",
  semester: "1st Semester",
  academicYear: "2023-2024",
  program: "BSCS",
  rating: 4.8
}
```

## Benefits

1. **Quality Assurance**: Experience-based assignments ensure quality education
2. **Workload Balance**: Considers current faculty load
3. **Data-Driven**: Uses historical teaching data
4. **Transparent**: Shows reasoning for recommendations
5. **Fair**: Prioritizes merit and experience
6. **Multilingual**: Accessible in multiple languages

## Future Enhancements

Potential improvements:
- Student feedback integration
- Peer review scores
- Research alignment
- Teaching certification levels
- Subject area expertise depth
- Faculty preferences and requests

---

**Last Updated**: December 2024
**Version**: 1.0
**AI Model**: Google Gemini 1.5 Flash with 5 fallback keys
